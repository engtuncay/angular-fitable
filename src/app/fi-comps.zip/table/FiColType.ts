export enum FiColType {
  double,
  string,
  integer,
  boolean
}

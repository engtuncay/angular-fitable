

export enum NgTableColType {

    double,
    string,
    integer,
    boolean

}

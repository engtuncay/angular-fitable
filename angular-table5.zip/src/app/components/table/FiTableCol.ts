export class FiTableCol {

    title:string;
    name:string;
    
    constructor() {
        
    }
}